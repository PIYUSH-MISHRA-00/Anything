/// Blueprint to ExperienceSpec converter.
///
/// Converts an AppBlueprint into an ExperienceSpec that the CreationEngine
/// can consume. This bridges the semantic synthesis layer with the
/// existing creation pipeline.
///
/// This converter does NOT contain domain-specific knowledge.
/// All category/interaction/UI derivation is based on blueprint structure.
library;

import '../application_engineering/engineering_plan.dart';
import '../creation/app_capabilities.dart';
import '../kernel/specification/experience_spec.dart';
import 'app_archetype.dart';
import 'app_blueprint.dart';

/// Converts an AppBlueprint into an ExperienceSpec.
class BlueprintToSpecConverter {
  /// Convert a validated AppBlueprint into an ExperienceSpec. [engineeringPlan]
  /// is carried through onto the resulting spec unchanged (Vision Milestone V3);
  /// omit it for every pre-V3 call site.
  static ExperienceSpec convert(
    AppBlueprint blueprint, {
    EngineeringPlan? engineeringPlan,
  }) {
    return ExperienceSpec(
      id: blueprint.id,
      name: blueprint.name,
      description: blueprint.description,
      category: _deriveCategory(blueprint),
      interactionModel: _deriveInteractionModel(blueprint),
      uiRequirements: _deriveUIRequirements(blueprint),
      functionalRequirements: _deriveFunctionalRequirements(blueprint),
      stateRequirements: _deriveStateRequirements(blueprint),
      storageRequirements: _deriveStorageRequirements(blueprint),
      dataEntities: _deriveDataEntities(blueprint),
      serviceRequirements: _deriveServiceRequirements(blueprint),
      networkRequirements: _deriveNetworkRequirements(blueprint),
      permissionRequirements: const [],
      backendClassification: _deriveBackendClassification(blueprint),
      requiredCapabilities: _deriveRequiredCapabilities(blueprint),
      protectionRequirements: const ProtectionRequirements(),
      runtimeRequirements: const RuntimeRequirements(),
      qualityRequirements: const QualityRequirements(),
      accessibilityRequirements: const AccessibilityRequirements(),
      offlineBehavior: _deriveOfflineBehavior(blueprint),
      createdAt: DateTime.now(),
      engineeringPlan: engineeringPlan,
    );
  }

  /// Derive category from blueprint structure and tags (not domain keywords).
  static ExperienceCategory _deriveCategory(AppBlueprint blueprint) {
    // Use archetypes to determine category
    if (blueprint.archetypes.contains(AppArchetype.utility)) {
      return ExperienceCategory.tool;
    }
    if (blueprint.archetypes.contains(AppArchetype.dashboard)) {
      return ExperienceCategory.productivity;
    }
    if (blueprint.archetypes.contains(AppArchetype.planner)) {
      return ExperienceCategory.productivity;
    }
    if (blueprint.archetypes.contains(AppArchetype.reference)) {
      return ExperienceCategory.reference;
    }
    if (blueprint.archetypes.contains(AppArchetype.tracker)) {
      return ExperienceCategory.productivity;
    }
    if (blueprint.networkConfig != null) {
      return ExperienceCategory.utility;
    }
    return ExperienceCategory.unknown;
  }

  static InteractionModel _deriveInteractionModel(AppBlueprint blueprint) {
    if (blueprint.archetypes.contains(AppArchetype.utility)) {
      return InteractionModel.directManipulation;
    }
    if (blueprint.archetypes.contains(AppArchetype.dashboard)) {
      return InteractionModel.dashboard;
    }
    if (blueprint.archetypes.contains(AppArchetype.planner)) {
      return InteractionModel.formBased;
    }
    if (blueprint.archetypes.contains(AppArchetype.tracker)) {
      return InteractionModel.formBased;
    }
    return InteractionModel.formBased;
  }

  static UIRequirements _deriveUIRequirements(AppBlueprint blueprint) {
    final primaryViews = blueprint.views.map((v) => v.name).toList();
    final inputElements = <String>[];
    for (final entity in blueprint.entities) {
      for (final field in entity.fields) {
        if (field.type != BlueprintFieldType.reference) {
          inputElements.add(field.name);
        }
      }
    }
    return UIRequirements(
      description: '${blueprint.name} interface',
      primaryViews: primaryViews,
      inputElements: inputElements,
      displayElements: blueprint.entities.map((e) => e.name).toList(),
    );
  }

  static List<FunctionalRequirement> _deriveFunctionalRequirements(
    AppBlueprint blueprint,
  ) {
    return blueprint.actions.map((action) {
      return FunctionalRequirement(
        id: action.id,
        description: action.name,
        acceptanceCriteria: [
          if (action.actionType == BlueprintActionType.create)
            'Creates a new ${action.targetEntityId}',
          if (action.actionType == BlueprintActionType.update)
            'Updates existing ${action.targetEntityId}',
          if (action.actionType == BlueprintActionType.delete)
            'Deletes ${action.targetEntityId}',
          if (action.actionType == BlueprintActionType.toggle)
            'Toggles ${action.targetEntityId} state',
        ],
      );
    }).toList();
  }

  static StateRequirements _deriveStateRequirements(AppBlueprint blueprint) {
    final stateEntities = <String>[];
    for (final entity in blueprint.entities) {
      stateEntities.add(entity.id);
    }
    return StateRequirements(
      description: 'State for ${blueprint.name}',
      requiresEphemeralState: true,
      requiresPersistentState: blueprint.entities.isNotEmpty,
      stateEntities: stateEntities,
    );
  }

  static StorageRequirements _deriveStorageRequirements(
    AppBlueprint blueprint,
  ) {
    final hasEntities = blueprint.entities.isNotEmpty;
    return StorageRequirements(
      description: hasEntities
          ? 'Local database for ${blueprint.name}'
          : 'No storage required',
      storageType: hasEntities
          ? StorageType.localDatabase
          : StorageType.ephemeral,
      requiresDatabase: hasEntities,
    );
  }

  static List<DataEntity> _deriveDataEntities(AppBlueprint blueprint) {
    return blueprint.entities.map((entity) {
      return DataEntity(
        name: entity.name,
        description: 'Entity: ${entity.name}',
      );
    }).toList();
  }

  static List<ServiceRequirement> _deriveServiceRequirements(
    AppBlueprint blueprint,
  ) {
    final services = <ServiceRequirement>[];
    if (blueprint.entities.isNotEmpty) {
      services.add(
        ServiceRequirement(
          id: 'localDatabase',
          description: 'Local SQLite database',
          type: ServiceType.localDatabase,
        ),
      );
    }
    return services;
  }

  static NetworkRequirements _deriveNetworkRequirements(
    AppBlueprint blueprint,
  ) {
    if (blueprint.networkConfig != null) {
      return NetworkRequirements(
        networkNeed: NetworkNeed.required,
        description: blueprint.networkConfig!.purpose,
      );
    }
    return NetworkRequirements(
      networkNeed: NetworkNeed.none,
      description: 'No network required',
    );
  }

  static BackendClassification _deriveBackendClassification(
    AppBlueprint blueprint,
  ) {
    if (blueprint.networkConfig != null) {
      return BackendClassification.externalApi;
    }
    if (blueprint.entities.isNotEmpty) {
      return BackendClassification.localDatabase;
    }
    return BackendClassification.none;
  }

  /// Platform capability IDs the Kernel registry can resolve (IS-P07/P10).
  ///
  /// App-level IDs (`networkData`, `calculation`, `crud`, …) describe
  /// generation/runtime shape. Passing them into Kernel Step 8 made every
  /// network/reference plan fail as "Some requirements cannot be met yet"
  /// after a paid model call — the human weather-dashboard failure mode.
  static const Set<String> _platformCapabilityIds = {
    'storage',
    'clock',
    'http',
    'ai',
    'knowledge',
    'notifications',
    'files',
  };

  static List<RequiredCapability> _deriveRequiredCapabilities(
    AppBlueprint blueprint,
  ) {
    final ids = <String>{};

    if (blueprint.entities.isNotEmpty) {
      ids.add('storage');
    }
    if (blueprint.networkConfig != null) {
      ids.add('http');
      ids.add('knowledge');
    }

    for (final capId in blueprint.requiredCapabilities) {
      if (_platformCapabilityIds.contains(capId)) {
        ids.add(capId);
        continue;
      }
      switch (capId) {
        case AppCapabilityIds.networkData:
        case AppCapabilityIds.webData:
        case AppCapabilityIds.refresh:
        case AppCapabilityIds.offlineCache:
        case AppCapabilityIds.synchronization:
          ids.add('http');
          ids.add('knowledge');
          break;
        case AppCapabilityIds.persistence:
        case AppCapabilityIds.crud:
        case AppCapabilityIds.entity:
        case AppCapabilityIds.collection:
        case AppCapabilityIds.secureStorage:
          ids.add('storage');
          break;
        case AppCapabilityIds.scheduling:
        case AppCapabilityIds.notifications:
          ids.add('notifications');
          ids.add('clock');
          break;
        case AppCapabilityIds.files:
        case AppCapabilityIds.media:
          ids.add('files');
          break;
        case AppCapabilityIds.timers:
          ids.add('clock');
          break;
        // UI/runtime-only capabilities are not Kernel resolve gates.
        default:
          break;
      }
    }

    return [
      for (final id in ids)
        RequiredCapability(capabilityId: id, isRequired: true),
    ];
  }

  static OfflineBehavior _deriveOfflineBehavior(AppBlueprint blueprint) {
    switch (blueprint.offlinePolicy) {
      case OfflinePolicy.full:
        return const OfflineBehavior(
          offlineCapability: OfflineCapability.fullyOffline,
          description: 'Works entirely offline',
        );
      case OfflinePolicy.partial:
        return const OfflineBehavior(
          offlineCapability: OfflineCapability.mostlyOffline,
          description: 'Mostly offline with optional network',
        );
      case OfflinePolicy.networkRequired:
        return const OfflineBehavior(
          offlineCapability: OfflineCapability.requiresNetwork,
          description: 'Requires network',
        );
    }
  }
}
