/// Home screen — the Universal Intent Surface.
///
/// Stage 9: Production Home with IntentComposer, BirthSequence, and voice.
library;

import 'package:flutter/material.dart';

import 'package:anything/app/app_composition.dart';
import 'package:anything/app/autonomous_workspace_runtime.dart';
import 'package:anything/app/creation_coordinator.dart';
import 'package:anything/app/experience_activation_manager.dart';
import 'package:anything/app/experience_entry_pipeline.dart';
import 'package:anything/app/experience_opening_coordinator.dart';
import 'package:anything/app/experience_workspace_manager.dart';
import 'package:anything/app/intent_execution_pipeline.dart';
import 'package:anything/app/universal_intent_router.dart';
import 'package:anything/app/workspace_event_publisher.dart';
import 'package:anything/app/workspace_lifecycle_policy_engine.dart';
import 'package:anything/app/workspace_runtime_supervisor.dart';
import 'package:anything/app/workspace_scheduling_engine.dart';
import 'package:anything/core/events/events.dart';
import 'package:anything/design_system/components/birth_sequence.dart';
import 'package:anything/design_system/components/anything_chip.dart';
import 'package:anything/design_system/components/anything_empty_state.dart';
import 'package:anything/design_system/components/anything_section_header.dart';
import 'package:anything/design_system/experience_icon.dart';
import 'package:anything/design_system/tokens/spacing.dart';
import 'package:anything/creation/creation_request.dart';
import 'package:anything/features/home/intent_composer.dart';
import 'package:anything/services/voice_service.dart';
import 'package:anything/storage/sqlite_experience_repository.dart';
import 'package:anything/storage/intent_repository.dart';
import 'package:anything/core/contracts/intent.dart' as core;
import 'package:anything/core/contracts/protection_provider.dart';
import 'package:anything/ai/provider_error.dart';
import 'package:anything/features/workspace/workspace_switcher.dart';

/// Home screen with production creation pipeline.
class HomeScreen extends StatefulWidget {
  /// Shared composition root (Implementation Milestone R1). Defaults to a
  /// fresh `AppComposition.production()` when not supplied — preserves
  /// exact prior behavior for any caller/test constructing `HomeScreen()`
  /// directly, though the real app (`AnythingAppShell`) always threads its
  /// own single shared instance.
  final AppComposition? composition;

  /// IS-P05 finding 1 — lets the "Your data" sheet route to Settings.
  /// Optional, so every existing caller and test is unaffected.
  final VoidCallback? onOpenSettings;

  /// Optional, additive workspace manager (Implementation Specification
  /// IS-R32) — `null` by default, so every existing caller/test that
  /// constructs `HomeScreen()` without one keeps identical behavior. Stored
  /// for a future caller to use; this milestone deliberately does NOT
  /// reroute `_createExperience`'s existing creation flow (its own
  /// `_showBirth`/`_creationReady` state machine) through it — real UI
  /// wiring deeper than accept-and-store is out of this milestone's honest,
  /// verifiable scope (see `docs/architecture/EXPERIENCE_WORKSPACE_MANAGER.md`).
  final ExperienceWorkspaceManager? workspaceManager;

  /// Optional, additive intent router (Implementation Specification IS-R33)
  /// — `null` by default, so every existing caller/test that constructs
  /// `HomeScreen()` without one keeps identical behavior. Stored for a
  /// future caller to use; matches R32's own precedent exactly — this
  /// milestone deliberately does NOT reroute `_createExperience`'s existing
  /// creation flow through it, for the same real regression-risk reasons
  /// R32 already gave for `workspaceManager` (see
  /// `docs/architecture/UNIVERSAL_INTENT_ROUTER.md`).
  final UniversalIntentRouter? intentRouter;

  /// Optional, additive workspace runtime (Implementation Specification
  /// IS-R34) — `null` by default, so every existing caller/test that
  /// constructs `HomeScreen()` without one keeps identical behavior.
  /// `AutonomousWorkspaceRuntime` exposes no mutation/report method (a
  /// pure, read-only snapshot aggregator) — there is no analogous "safe
  /// extra step" to wire here the way R32 found for `ExperienceHostScreen`
  /// and `workspaceManager`; accept-and-store is the honest, real limit
  /// (see `docs/architecture/AUTONOMOUS_WORKSPACE_RUNTIME.md`).
  final AutonomousWorkspaceRuntime? workspaceRuntime;

  /// Optional, additive event bus (Implementation Specification IS-R35) —
  /// `null` by default, so every existing caller/test that constructs
  /// `HomeScreen()` without one keeps identical behavior. `EventBus`
  /// (`lib/core/events/events.dart`) already existed, real and tested,
  /// with zero production callers before this milestone — stored here for
  /// a future caller to publish/subscribe through; accept-and-store
  /// matches every prior optional-injection parameter on this screen.
  final EventBus? eventBus;

  /// Optional, additive intent execution pipeline (Implementation
  /// Specification IS-R37) — `null` by default, so every existing
  /// caller/test that constructs `HomeScreen()` without one keeps identical
  /// behavior. REALITY before R37: `_createExperience()` called
  /// `ExperienceCreationCoordinator.createFromIntent()` directly, bypassing
  /// `UniversalIntentRouter` entirely — the real production creation flow
  /// never registered its session in `ExperienceWorkspaceManager`. This
  /// milestone reroutes `_createExperience()` through
  /// `IntentExecutionPipeline.execute()` instead — the ONE thing this
  /// screen now calls to get engineering work done (see
  /// `docs/architecture/INTENT_EXECUTION_PIPELINE.md`).
  final IntentExecutionPipeline? pipeline;

  /// Optional, additive runtime supervisor (Implementation Specification
  /// IS-R41) — `null` by default, so every existing caller/test that
  /// constructs `HomeScreen()` without one keeps identical behavior.
  /// REALITY before R41: `WorkspaceRuntimeSupervisor` (R40) had no shared
  /// composition-root instance — threaded into `ExperienceHostScreen` at
  /// every real navigation call site below, so every screen this app opens
  /// registers with the SAME supervisor (see
  /// `docs/architecture/SHARED_RUNTIME_SUPERVISION.md`).
  final WorkspaceRuntimeSupervisor? runtimeSupervisor;

  /// Optional, additive scheduling engine (Implementation Specification
  /// IS-R43) — `null` by default, so every existing caller/test that
  /// constructs `HomeScreen()` without one keeps identical behavior.
  /// REALITY before R43: `WorkspaceSchedulingEngine` (R42) had no shared
  /// composition-root instance — threaded into `ExperienceHostScreen` at
  /// every real navigation call site below (its own `scheduler` field,
  /// added R42, was always `null` in production until now), and consumed by
  /// the new Workspace Experience Switcher opened from this screen's own
  /// header (see `docs/architecture/WORKSPACE_EXPERIENCE_SWITCHER.md`).
  final WorkspaceSchedulingEngine? scheduler;

  /// Optional, additive activation manager (Implementation Specification
  /// IS-R44) — `null` by default, so every existing caller/test that
  /// constructs `HomeScreen()` without one keeps identical behavior.
  /// REALITY before R44: every real `ExperienceHostScreen` push here went
  /// straight through `Navigator.push`, with no way to avoid pushing a
  /// second screen for an already-open session (the real gap R43's own
  /// Switcher explicitly deferred). Every real navigation call site below
  /// now routes through this manager instead (see
  /// `docs/architecture/EXPERIENCE_ACTIVATION_MANAGER.md`).
  final ExperienceActivationManager? activationManager;

  /// Optional, additive unified entry pipeline (Implementation
  /// Specification IS-R45) — `null` by default, so every existing
  /// caller/test that constructs `HomeScreen()` without one keeps identical
  /// behavior. REALITY before R45: every real Experience-opening path here
  /// (Recent list, birth completion, protection resume, and the
  /// `CreationOpened` reopen branch) called `ExperienceOpeningCoordinator`
  /// directly, then activated with `sessionId: null` always — no workspace
  /// session was ever registered for any of them. This screen now routes
  /// every one of those paths through this pipeline instead (see
  /// `docs/architecture/UNIFIED_EXPERIENCE_ENTRY_PIPELINE.md`).
  final ExperienceEntryPipeline? entryPipeline;

  const HomeScreen({
    super.key,
    this.composition,
    this.onOpenSettings,
    this.workspaceManager,
    this.intentRouter,
    this.workspaceRuntime,
    this.eventBus,
    this.pipeline,
    this.runtimeSupervisor,
    this.scheduler,
    this.activationManager,
    this.entryPipeline,
  });

  @override
  HomeScreenState createState() => HomeScreenState();
}

class HomeScreenState extends State<HomeScreen> {
  late final AppComposition _composition;

  /// Real, resolved AI Operating System services (Implementation
  /// Specification IS-R36) — an explicit, caller-supplied [widget] instance
  /// wins (preserves every existing test's ability to inject a fake/double,
  /// e.g. for identity checks), otherwise the shared instance from
  /// [_composition] (Implementation Specification IS-R36 extended
  /// `AppComposition` to hold these). Threaded into `ExperienceHostScreen`
  /// at every real navigation call site below.
  late final ExperienceWorkspaceManager _workspaceManager;
  late final UniversalIntentRouter _intentRouter;
  late final AutonomousWorkspaceRuntime _workspaceRuntime;
  late final EventBus _eventBus;

  /// Real, resolved Intent Execution Pipeline (Implementation Specification
  /// IS-R37) — the ONE thing `_createExperience()` calls to get engineering
  /// work done; see [HomeScreen.pipeline]'s own doc comment.
  late final IntentExecutionPipeline _pipeline;

  /// Real, resolved Workspace Runtime Supervisor (Implementation
  /// Specification IS-R41) — threaded into `ExperienceHostScreen` at every
  /// real navigation call site below; see [HomeScreen.runtimeSupervisor]'s
  /// own doc comment.
  late final WorkspaceRuntimeSupervisor _runtimeSupervisor;

  /// Real, resolved Workspace Scheduling Engine (Implementation
  /// Specification IS-R43) — threaded into `ExperienceHostScreen` at every
  /// real navigation call site below, and consumed directly by the
  /// Workspace Experience Switcher this screen opens; see
  /// [HomeScreen.scheduler]'s own doc comment.
  late final WorkspaceSchedulingEngine _scheduler;

  /// Real, resolved Experience Activation Manager (Implementation
  /// Specification IS-R44) — the ONE thing every real
  /// `ExperienceHostScreen` navigation call site below goes through; see
  /// [HomeScreen.activationManager]'s own doc comment.
  late final ExperienceActivationManager _activationManager;

  /// Real, resolved Unified Experience Entry Pipeline (Implementation
  /// Specification IS-R45) — the ONE thing every real Experience-opening
  /// call site below goes through; see [HomeScreen.entryPipeline]'s own
  /// doc comment.
  late final ExperienceEntryPipeline _entryPipeline;
  late final SqliteExperienceRepository _repository;
  late final IntentRepository _intentRepository;
  late final IntentComposer _composer;
  late final VoiceInputService _voiceService;
  final TextEditingController _textController = TextEditingController();
  final FocusNode _focusNode = FocusNode();
  List<ExperienceMetadataRecord> _recentExperiences = [];

  /// The Experience ID created by the current creation flow.
  /// Used by birth completion to open the exact Experience.
  String? _createdExperienceId;
  String? _createdExperienceName;

  /// Focus the intent input field for external navigation.
  void focusIntentField() {
    _focusNode.requestFocus();
  }

  /// Real, resolved Universal Intent Router (Implementation Specification
  /// IS-R36) — exposed for identity/dependency-injection tests. Unlike
  /// [_workspaceManager]/[_workspaceRuntime]/[_eventBus], this screen has no
  /// safe forwarding point for it yet (`ExperienceHostScreen` has no
  /// `intentRouter` parameter — matches R33's own documented, honest
  /// "accept-and-store" limit); this getter is the real way a caller/test
  /// observes the resolved instance.
  UniversalIntentRouter get intentRouterInUse => _intentRouter;

  bool _isListening = false;
  bool _showBirth = false;
  String _birthName = '';
  final ValueNotifier<bool> _creationReady = ValueNotifier(false);

  @override
  void initState() {
    super.initState();
    // Implementation Milestone R1: the Kernel/KnowledgeAcquisitionEngine/
    // ProviderRegistry/WorldModelCoordinator are no longer constructed
    // here — they come from the single shared `AppComposition`, so this
    // screen, `ExperienceHostScreen`, and `ExperiencesScreen` all read and
    // write the SAME World Graph and provider registry (MIS-1 Part 2's
    // ownership finding).
    _composition = widget.composition ?? AppComposition.production();
    // IS-R45 fix (corrected — see the `_scheduler` resolution below for the
    // full reasoning): `_workspaceManager` must resolve to the SAME real
    // instance `_scheduler` is (or will be) bound to, or
    // `WorkspaceSchedulingEngine.scheduleForeground()` ->
    // `ExperienceWorkspaceManager.switchActiveExperience()` throws a real
    // `StateError` ("not open in this workspace") the moment R45's
    // registration step registers a session in one workspace while the
    // scheduler is bound to a different one. When a caller supplies
    // `scheduler:` WITHOUT also supplying `workspaceManager:`, prefer the
    // scheduler's own real, already-bound workspace over the unrelated
    // composition default — the exact inverse of the case handled below.
    _workspaceManager =
        widget.workspaceManager ??
        widget.scheduler?.workspace ??
        _composition.workspaceManager;
    _intentRouter = widget.intentRouter ?? _composition.intentRouter;
    _workspaceRuntime =
        widget.workspaceRuntime ?? _composition.workspaceRuntime;
    _eventBus = widget.eventBus ?? _composition.eventBus;
    // Implementation Specification IS-R37: sourced from the shared
    // `AppComposition` instead of calling `ExperienceCreationCoordinator`
    // directly here — REALITY before R37 (confirmed by grep): this was the
    // ONE real, live production intent-entry point that bypassed
    // `UniversalIntentRouter` entirely. See
    // `docs/architecture/INTENT_EXECUTION_PIPELINE.md`.
    _pipeline = widget.pipeline ?? _composition.intentExecutionPipeline;
    _runtimeSupervisor =
        widget.runtimeSupervisor ?? _composition.workspaceRuntimeSupervisor;
    // IS-R45 fix: `_composition.workspaceSchedulingEngine` is bound to
    // `_composition`'s OWN `workspaceManager`/`workspaceRuntime`/`eventBus`
    // internally. If a caller overrides any of those three without also
    // overriding `scheduler`, the composition default would silently
    // reference a DIFFERENT workspace than the one this screen actually
    // uses — invisible until something calls `scheduler.scheduleForeground()`
    // for a session that only exists in the overridden workspace (R45's new
    // Recent-flow registration is the first real caller to do so). Build a
    // fresh, consistent scheduler from this screen's own resolved fields in
    // that case; the bare/no-override case keeps using the exact shared
    // singleton (identity-sensitive tests are unaffected). The OPPOSITE
    // direction (scheduler overridden, workspaceManager not) never needs a
    // fresh scheduler — `_workspaceManager`'s own resolution above already
    // adopted `widget.scheduler.workspace`, so `widget.scheduler` itself is
    // already consistent and used directly.
    final needsConsistentScheduler =
        widget.scheduler == null &&
        (widget.workspaceManager != null ||
            widget.workspaceRuntime != null ||
            widget.eventBus != null);
    _scheduler =
        widget.scheduler ??
        (needsConsistentScheduler
            ? WorkspaceSchedulingEngine(
                workspaceRuntime: _workspaceRuntime,
                supervisor: _runtimeSupervisor,
                policyEngine: const WorkspaceLifecyclePolicyEngine(),
                workspace: _workspaceManager,
                eventPublisher: WorkspaceEventPublisher(bus: _eventBus),
              )
            : _composition.workspaceSchedulingEngine);
    _activationManager =
        widget.activationManager ??
        (identical(_scheduler, _composition.workspaceSchedulingEngine)
            ? _composition.experienceActivationManager
            : ExperienceActivationManager(
                scheduler: _scheduler,
                eventPublisher: WorkspaceEventPublisher(bus: _eventBus),
              ));
    // Implementation Specification IS-R45: built from THIS screen's own
    // individually-resolved fields above (never from `_composition`
    // directly) so every existing, established per-field override
    // (`workspaceManager:`/`runtimeSupervisor:`/etc., R32-R44's own
    // convention) keeps taking real effect in the real navigation path —
    // an explicit `widget.entryPipeline` override still wins outright, for
    // callers/tests that want to inject the whole pipeline at once. A
    // fresh `ExperienceOpeningCoordinator()` matches this screen's own
    // pre-R45 behavior exactly (never shared, always constructed locally).
    _entryPipeline =
        widget.entryPipeline ??
        ExperienceEntryPipeline(
          intentExecutionPipeline: _pipeline,
          openingCoordinator: ExperienceOpeningCoordinator(
            activity: _composition.activityRepository,
          ),
          activationManager: _activationManager,
          workspaceManager: _workspaceManager,
          worldModel: _composition.worldModel,
          capabilityPlatform: _composition.capabilityPlatform,
          engineeringMemory: _composition.engineeringMemory,
          workspaceRuntime: _workspaceRuntime,
          eventBus: _eventBus,
          runtimeSupervisor: _runtimeSupervisor,
          scheduler: _scheduler,
        );
    _repository = _composition.experienceRepository;
    _intentRepository = _composition.intentRepository;
    _composer = IntentComposer(_composition.kernel);
    _voiceService = VoiceInputService();
    _voiceService.addListener(_onVoiceStateChanged);
    // IS-P11: Home must observe the same library revision My Apps does.
    // Delete/create/import mutate via ExperienceCommitFramework → revision;
    // without this listener Recent stayed stale after My Apps delete.
    _composition.experienceLibraryRevision.addListener(_onLibraryRevision);
    _loadRecent();
  }

  void _onLibraryRevision() {
    if (mounted) _loadRecent();
  }

  @override
  void dispose() {
    _composition.experienceLibraryRevision.removeListener(_onLibraryRevision);
    _voiceService.removeListener(_onVoiceStateChanged);
    _voiceService.dispose();
    _textController.dispose();
    _focusNode.dispose();
    _creationReady.dispose();
    _composer.dispose();
    super.dispose();
  }

  void _onVoiceStateChanged() {
    if (mounted) {
      setState(() {
        _isListening = _voiceService.isListening;
        if (_voiceService.currentText.isNotEmpty) {
          _textController.text = _voiceService.currentText;
          _composer.setExpression(_voiceService.currentText);
        }
      });
    }
  }

  Future<void> _loadRecent() async {
    final experiences = await _repository.listAll(limit: 5);
    if (mounted) setState(() => _recentExperiences = experiences);
  }

  /// IS-P08: guards re-entry. The submit BUTTON was disabled while
  /// `_showBirth` was true, but `TextField.onSubmitted` reaches this method
  /// with no such check, so a keyboard "send" during an in-flight creation
  /// started a second one against the same coordinator — which carries a
  /// single mutable `_state`. A dedicated flag, not `_showBirth`, because
  /// `_showBirth` is animation state and is cleared before the work is done.
  bool _isCreating = false;

  void _handleSubmit(String text) {
    final expression = text.trim();
    if (expression.isEmpty || _isCreating) return;
    _createExperience(expression);
  }

  Future<void> _createExperience(String expression) async {
    _isCreating = true;
    // IS-P12: freeze the prompt at submit so mutable composer state cannot
    // change the meaning of this request after submission.
    final creationRequest = CreationRequest.capture(rawPrompt: expression);
    _composer.setExpression(creationRequest.normalizedPrompt);
    final drafted = _composer.createIntent();
    final intent = drafted.copyWith(
      context: {
        ...drafted.context,
        'requestId': creationRequest.requestId,
        'normalizedPrompt': creationRequest.normalizedPrompt,
      },
    );

    // IS-P08: clear NOW, not on completion. Leaving the text in place was
    // reported as a defect and it is worse than untidy — the next prompt is
    // appended to this one, so "a calculator" followed by "a weather
    // dashboard" is submitted as "a calculatora weather dashboard", which
    // bills the user for a request that describes nothing. The text is put
    // back if creation fails, so a failed attempt is still editable.
    _textController.clear();
    _composer.clear();

    await _intentRepository.save(IntentRecord.fromIntent(intent));
    await _intentRepository.updateStatus(
      intent.id,
      core.IntentStatus.submitted,
    );

    setState(() {
      _showBirth = true;
      _birthName = creationRequest.normalizedPrompt;
      _creationReady.value = false;
      _createdExperienceId = null;
      _createdExperienceName = null;
    });

    // Implementation Specification IS-R37: routed through the ONE canonical
    // production `IntentExecutionPipeline` instead of calling
    // `ExperienceCreationCoordinator` directly — `RouteTarget.newExperience()`
    // preserves this box's exact existing UX contract (every submission
    // independently creates a new experience; there is no "continue" UI
    // affordance on Home), while genuinely registering the resulting
    // session in `ExperienceWorkspaceManager` for the first time.
    RoutingResult? routingResult;
    try {
      routingResult = await _pipeline.execute(
        intent,
        target: const RouteTarget.newExperience(),
      );
    } catch (e) {
      // IS-P22: pipeline exceptions must NEVER trap the user in the birth
      // animation. Restore usable Home state and show a meaningful error.
      await _intentRepository.updateStatus(intent.id, core.IntentStatus.failed);
      _restoreComposer(creationRequest.rawPrompt);
      if (mounted) {
        setState(() => _showBirth = false);
        final safe = e is ProviderException ? e.message : null;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(safe ?? 'Something went wrong creating this app.'),
            duration: const Duration(seconds: 10),
            action: SnackBarAction(
              label: 'Retry',
              onPressed: () => _handleSubmit(creationRequest.rawPrompt),
            ),
          ),
        );
      }
      return;
    } finally {
      _isCreating = false;
    }

    final result = routingResult.creationResult;

    if (!mounted) return;

    if (result is CreationCreated) {
      await _intentRepository.updateStatus(
        intent.id,
        core.IntentStatus.accepted,
      );
      // Store the EXACT created Experience ID for birth completion.
      setState(() {
        _createdExperienceId = result.experienceId;
        _createdExperienceName = result.package.manifest.name;
        _creationReady.value = true;
      });
    } else if (result is CreationOpened) {
      await _intentRepository.updateStatus(
        intent.id,
        core.IntentStatus.accepted,
      );
      setState(() => _showBirth = false);
      // Use the trusted opening coordinator for CreationOpened.
      await _openViaCoordinator(result.experienceId, result.experienceName);
    } else if (result is CreationFailed) {
      await _intentRepository.updateStatus(intent.id, core.IntentStatus.failed);
      _restoreComposer(creationRequest.rawPrompt);
      setState(() => _showBirth = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(result.message),
            duration: const Duration(seconds: 10),
            action: SnackBarAction(
              label: 'Retry',
              onPressed: () => _handleSubmit(creationRequest.rawPrompt),
            ),
          ),
        );
      }
    } else if (result is CreationProviderRequired) {
      await _intentRepository.updateStatus(intent.id, core.IntentStatus.failed);
      _restoreComposer(creationRequest.rawPrompt);
      setState(() => _showBirth = false);
      if (mounted) {
        // IS-P07: the refusal names the destination, so the snackbar goes
        // there. Telling someone to visit Settings and making them find it is
        // most of the friction.
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(result.message),
            duration: const Duration(seconds: 8),
            action: widget.onOpenSettings == null
                ? null
                : SnackBarAction(
                    label: 'Settings',
                    onPressed: widget.onOpenSettings!,
                  ),
          ),
        );
      }
    }
  }

  /// Puts a failed prompt back so the user can edit and retry it instead of
  /// retyping it from memory.
  void _restoreComposer(String expression) {
    if (!mounted || _textController.text.isNotEmpty) return;
    _textController.text = expression;
    _composer.setExpression(expression);
  }

  void _onBirthComplete() {
    setState(() => _showBirth = false);

    // Open the EXACT Experience created by the current creation flow.
    // Do not infer from _recentExperiences.first.
    final createdId = _createdExperienceId;
    final createdName = _createdExperienceName;

    if (createdId != null && mounted) {
      _openViaCoordinator(createdId, createdName ?? _birthName);
    }

    _loadRecent();
  }

  /// Open an Experience through the unified entry pipeline (Implementation
  /// Specification IS-R45) — real workspace-session registration (if none
  /// exists yet) and real runtime + navigation activation, replacing the
  /// pre-R45 direct `ExperienceOpeningCoordinator` + raw-`activate()` call
  /// that always left `sessionId: null`.
  Future<void> _openViaCoordinator(
    String experienceId,
    String experienceName,
  ) async {
    if (!mounted) return;

    final result = await _entryPipeline.activateExperience(
      Navigator.of(context),
      experienceId,
    );

    if (!mounted) return;

    switch (result) {
      case OpenReady():
        _loadRecent();

      case OpenProtectionInputRequired():
        // Show time input flow, then resume through the pipeline.
        await _showProtectionInputAndResume(
          result.experienceId,
          result.experienceName,
        );

      case OpenNotFound(:final message):
        if (mounted) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text(message)));
        }
      case OpenInvalid(:final message):
        if (mounted) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text(message)));
        }
      case OpenFailed(:final message):
        if (mounted) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text(message)));
        }
    }
  }

  /// Show the protection time input flow and resume opening through coordinator.
  Future<void> _showProtectionInputAndResume(
    String experienceId,
    String experienceName,
  ) async {
    if (!mounted) return;

    final option = await showModalBottomSheet<String>(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.access_time),
              title: const Text('Use current time'),
              onTap: () => Navigator.pop(context, 'current'),
            ),
            ListTile(
              leading: const Icon(Icons.calendar_today),
              title: const Text('Choose date & time'),
              onTap: () => Navigator.pop(context, 'custom'),
            ),
            ListTile(
              leading: const Icon(Icons.close),
              title: const Text('Cancel'),
              onTap: () => Navigator.pop(context, null),
            ),
          ],
        ),
      ),
    );

    if (option == null || !mounted) return;

    if (option == 'current') {
      // Minute precision + previous-minute fallback (protect/reopen across
      // a minute boundary is the common device path).
      final now = DateTime.now();
      OpenResult? openResult;
      for (final offsetMinutes in const [0, -1]) {
        final t = now.add(Duration(minutes: offsetMinutes));
        final timeSeed = TimeSeed(hours: t.hour, minutes: t.minute, seconds: 0);
        openResult = await _entryPipeline.activateProtectedExperience(
          Navigator.of(context),
          experienceId: experienceId,
          timeSeed: timeSeed,
        );
        if (openResult is OpenReady) break;
      }
      if (openResult is OpenReady && mounted) {
        _loadRecent();
      } else if (openResult is OpenFailed && mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(openResult.message)));
      }
    } else if (option == 'custom') {
      final now = DateTime.now();
      final selectedDate = await showDatePicker(
        context: context,
        initialDate: now,
        firstDate: now,
        lastDate: DateTime(now.year + 5),
      );
      if (selectedDate == null || !mounted) return;

      final selectedTime = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.now(),
      );
      if (selectedTime == null || !mounted) return;

      final customDateTime = DateTime(
        selectedDate.year,
        selectedDate.month,
        selectedDate.day,
        selectedTime.hour,
        selectedTime.minute,
      );

      final timeSeed = TimeSeed(
        hours: customDateTime.hour,
        minutes: customDateTime.minute,
        seconds: customDateTime.second,
      );

      // Implementation Specification IS-R45: same real pipeline routing as
      // the "current time" branch above.
      final openResult = await _entryPipeline.activateProtectedExperience(
        Navigator.of(context),
        experienceId: experienceId,
        timeSeed: timeSeed,
      );
      if (openResult is OpenReady && mounted) {
        _loadRecent();
      } else if (openResult is OpenFailed && mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(openResult.message)));
      }
    }
  }

  /// Open an Experience from the recent list via the unified entry pipeline.
  void _openExperience(ExperienceMetadataRecord exp) async {
    await _openViaCoordinator(exp.id, exp.name);
  }

  Future<void> _handleVoiceTap() async {
    if (_isListening) {
      await _voiceService.stopListening();
    } else {
      await _voiceService.startListening();
    }
  }

  /// IS-P05 finding 1 — what the profile affordance actually opens.
  ///
  /// Deliberately NOT an account screen: Anything is local-first and has no
  /// accounts, so a sign-in surface would promise something that does not
  /// exist. This answers the question the icon actually raises.
  Future<void> _showDataSheet() async {
    final experiences = await _repository.listAll();
    if (!mounted) return;
    final colorScheme = Theme.of(context).colorScheme;

    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Your data',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                  color: colorScheme.onSurface,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Anything has no account and no server. Everything below is '
                'on this device only.',
                style: TextStyle(
                  fontSize: 14,
                  height: 1.4,
                  color: colorScheme.onSurfaceVariant,
                ),
              ),
              const SizedBox(height: 20),
              _DataRow(
                icon: Icons.auto_awesome,
                label: 'Apps you have created',
                value: '${experiences.length}',
              ),
              _DataRow(
                icon: Icons.vpn_key_outlined,
                label: 'AI provider key',
                value: 'Stored in the device keystore',
              ),
              _DataRow(
                icon: Icons.cloud_off_outlined,
                label: 'Uploaded anywhere',
                value: 'Nothing',
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () {
                        Navigator.pop(sheetContext);
                        widget.onOpenSettings?.call();
                      },
                      icon: const Icon(Icons.tune),
                      label: const Text('Settings'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    if (_showBirth) {
      return BirthSequence(
        experienceName: _birthName,
        icon: Icons.auto_awesome,
        creationReady: _creationReady,
        onComplete: _onBirthComplete,
        reducedMotion: MediaQuery.of(context).disableAnimations,
      );
    }

    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(
              AnythingPadding.regular,
              16,
              AnythingPadding.regular,
              0,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Anything',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w600,
                    color: colorScheme.onSurface,
                    letterSpacing: -0.01,
                  ),
                ),
                Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.apps),
                      tooltip: 'Running apps',
                      onPressed: () => showWorkspaceSwitcher(
                        context,
                        _scheduler,
                        entryPipeline: _entryPipeline,
                      ),
                    ),
                    // IS-P05 finding 1. THE ROOT CAUSE: this was a bare
                    // Container with an Icon and NO onTap. It was never a
                    // button -- it was decoration that looked like one, which
                    // is why manual testing found it opened nothing. It was
                    // also invisible to a screen reader.
                    //
                    // Anything has no accounts and never will (local-first),
                    // so there is no profile to show. What a person actually
                    // wants from this affordance is "what does this app know
                    // about me, and where is it" -- so it opens a summary of
                    // exactly that.
                    Semantics(
                      button: true,
                      label: 'Your data',
                      child: Material(
                        color: colorScheme.surfaceContainerHigh,
                        shape: const CircleBorder(),
                        clipBehavior: Clip.antiAlias,
                        child: InkWell(
                          onTap: _showDataSheet,
                          child: SizedBox(
                            width: 44,
                            height: 44,
                            child: Icon(
                              Icons.person_outline,
                              size: 20,
                              color: colorScheme.onSurfaceVariant,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),

        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(
              AnythingPadding.regular,
              24,
              AnythingPadding.regular,
              0,
            ),
            child: _buildIntentField(context),
          ),
        ),

        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(
              AnythingPadding.regular,
              24,
              AnythingPadding.regular,
              0,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Try asking for',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.08,
                    color: colorScheme.onSurfaceVariant,
                  ),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    AnythingChip(
                      label: 'Calculator',
                      icon: Icons.calculate,
                      onTap: () => _createExperience('Make me a calculator'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),

        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(
              AnythingPadding.regular,
              32,
              AnythingPadding.regular,
              0,
            ),
            child: AnythingSectionHeader(title: 'Recent'),
          ),
        ),

        if (_recentExperiences.isEmpty)
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(
                AnythingPadding.regular,
                16,
                AnythingPadding.regular,
                0,
              ),
              child: AnythingEmptyState(
                icon: Icons.auto_awesome,
                title: 'No apps yet',
                message: 'Apps you create will appear here.',
                actionLabel: 'Create your first',
                onAction: () => _focusNode.requestFocus(),
              ),
            ),
          )
        else
          SliverPadding(
            padding: const EdgeInsets.symmetric(
              horizontal: AnythingPadding.regular,
            ),
            sliver: SliverList(
              delegate: SliverChildBuilderDelegate((context, index) {
                final exp = _recentExperiences[index];
                return ListTile(
                  leading: ExperienceIcon(
                    experienceId: exp.id,
                    name: exp.name,
                    category: exp.category,
                    size: 40,
                  ),
                  title: Text(exp.name),
                  subtitle: Text(
                    exp.description.isNotEmpty ? exp.description : 'App',
                  ),
                  trailing: Icon(
                    Icons.chevron_right,
                    color: colorScheme.onSurfaceVariant,
                  ),
                  onTap: () => _openExperience(exp),
                );
              }, childCount: _recentExperiences.length),
            ),
          ),

        const SliverToBoxAdapter(child: SizedBox(height: 120)),
      ],
    );
  }

  Widget _buildIntentField(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      decoration: BoxDecoration(
        color: isDark
            ? colorScheme.surfaceContainer
            : colorScheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(isDark ? 8 : 24),
        border: Border.all(
          color: _focusNode.hasFocus
              ? colorScheme.primary.withAlpha(128)
              : Colors.transparent,
          width: 2,
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _textController,
              focusNode: _focusNode,
              onChanged: (text) => _composer.setExpression(text),
              onSubmitted: _handleSubmit,
              textInputAction: TextInputAction.send,
              maxLines: null,
              minLines: 1,
              style: TextStyle(fontSize: 16, color: colorScheme.onSurface),
              decoration: InputDecoration(
                hintText: 'What do you want?',
                hintStyle: TextStyle(
                  color: colorScheme.onSurfaceVariant.withAlpha(128),
                  fontSize: 16,
                ),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 16,
                ),
              ),
            ),
          ),
          // Implementation Specification IS-R47 Task 3 — submit-button
          // reactivity. REALITY before this fix (found while writing R45's
          // tests, documented as a known limitation through R45 and R46):
          // this `AnimatedSwitcher` branches on `_textController.text`, but
          // nothing rebuilt the widget when that text changed.
          // `TextField.onChanged` calls `_composer.setExpression()`, which
          // notifies `IntentComposer`'s listeners — and `HomeScreen` was not
          // one of them. So typing alone never revealed the submit button;
          // it appeared only on the next unrelated `setState` (e.g. a focus
          // change or a voice-state event).
          //
          // `TextEditingController` IS a `ValueListenable<TextEditingValue>`,
          // so the fix is the native Flutter mechanism rather than new state:
          // listen to the controller that is already the source of truth, and
          // rebuild ONLY this icon subtree. A `_textController.addListener(
          // () => setState(...))` in `initState` would also work but would
          // rebuild the entire screen on every keystroke and add a listener
          // to remove in `dispose()`.
          //
          // Business logic is untouched: `onChanged` still calls
          // `_composer.setExpression()`, and no scheduler, activation or
          // entry-pipeline behavior changes.
          ValueListenableBuilder<TextEditingValue>(
            valueListenable: _textController,
            builder: (context, value, _) => AnimatedSwitcher(
              duration: const Duration(milliseconds: 100),
              transitionBuilder: (child, animation) =>
                  ScaleTransition(scale: animation, child: child),
              child: value.text.isNotEmpty
                  ? IconButton(
                      key: const ValueKey('submit'),
                      onPressed: _showBirth
                          ? null
                          : () => _handleSubmit(_textController.text),
                      icon: Icon(
                        Icons.arrow_upward,
                        color: colorScheme.onPrimary,
                        size: 22,
                      ),
                      style: IconButton.styleFrom(
                        backgroundColor: colorScheme.primary,
                        shape: const CircleBorder(),
                        padding: const EdgeInsets.all(8),
                      ),
                      tooltip: 'Submit',
                    )
                  : IconButton(
                      key: const ValueKey('voice'),
                      onPressed: _handleVoiceTap,
                      icon: Icon(
                        _isListening ? Icons.mic : Icons.mic_none,
                        color: _isListening
                            ? colorScheme.error
                            : colorScheme.onSurfaceVariant,
                        size: 22,
                      ),
                      // ACCESSIBILITY (IS-P03 Phase 5). The icon changes to
                      // signal recording, which is invisible to a screen
                      // reader. The label carries the state instead, so a
                      // blind user can tell whether the microphone is live.
                      tooltip: _isListening
                          ? 'Listening. Tap to stop'
                          : 'Voice input',
                    ),
            ),
          ),
          const SizedBox(width: 8),
        ],
      ),
    );
  }
}

/// One line in the "Your data" sheet (IS-P05 finding 1).
class _DataRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _DataRow({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          ExcludeSemantics(
            child: Icon(icon, size: 20, color: colorScheme.onSurfaceVariant),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Text(
              label,
              style: TextStyle(fontSize: 14, color: colorScheme.onSurface),
            ),
          ),
          Text(
            value,
            style: TextStyle(fontSize: 14, color: colorScheme.onSurfaceVariant),
          ),
        ],
      ),
    );
  }
}
