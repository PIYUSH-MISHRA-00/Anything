/// Persistence / Migration / Offline / Synchronization Engineering.
///
/// Synchronization stays strictly architecture-only, per the milestone's
/// explicit instruction: no server code, no network client is written —
/// only a typed, justified strategy record.
library;

import '../feature_discovery/feature_types.dart';
import '../software_architect/architecture_candidate.dart';
import '../software_architect/architecture_types.dart'
    show OfflineCapability, SyncStrategy;
import '../software_architect/confidence.dart';
import 'engineering_types.dart';

class PersistenceEngineeringResult {
  final List<EngineeringDecision> entityStorageDecisions;
  final EngineeringDecision migrationDecision;

  const PersistenceEngineeringResult({
    this.entityStorageDecisions = const [],
    required this.migrationDecision,
  });
}

class PersistenceEngineering {
  const PersistenceEngineering();

  PersistenceEngineeringResult plan(
    ArchitectureCandidate candidate,
    EngineeringDecision migrationDecision,
  ) {
    final decisions = candidate.entities.map((e) {
      return EngineeringDecision(
        id: 'persistence:${e.entityId}',
        category: EngineeringDecisionCategory.persistence,
        subjectId: e.entityId,
        decision: 'Persist via ${e.storage.name}',
        rationale: e.storageDecision.rationale,
        confidence: e.storageDecision.confidence,
      );
    }).toList();

    return PersistenceEngineeringResult(
      entityStorageDecisions: decisions,
      migrationDecision: migrationDecision,
    );
  }
}

enum OfflineStrategy {
  offlineFirst,
  cacheFirst,
  onlineRequired,
  deferredSync,
  readOnly,
}

enum ConflictStrategy { lastWriteWins, none }

class OfflineEngineeringResult {
  final OfflineStrategy strategy;
  final ConflictStrategy conflictStrategy;
  final EngineeringDecision decision;

  const OfflineEngineeringResult({
    required this.strategy,
    required this.conflictStrategy,
    required this.decision,
  });
}

class OfflineEngineering {
  const OfflineEngineering();

  /// [featureGraph] is the Feature Discovery Engine's approved output
  /// (Vision Milestone V4), if available — cross-referenced only to
  /// corroborate/cite the discovered Offline Strategy feature's priority
  /// in the rationale; the strategy itself is still decided from the real
  /// ArchitectureCandidate, exactly as before this cross-reference existed.
  OfflineEngineeringResult plan(
    ArchitectureCandidate candidate, {
    FeatureGraph? featureGraph,
  }) {
    final strategy = switch (candidate.offline.capability) {
      OfflineCapability.fullyOffline => OfflineStrategy.offlineFirst,
      OfflineCapability.cacheThenOnline => OfflineStrategy.cacheFirst,
      OfflineCapability.onlineRequired => OfflineStrategy.onlineRequired,
    };
    // Conflict resolution only matters once concurrent writers exist
    // (i.e. a real sync target) — today there is none (see
    // SynchronizationEngineering below), so "none" is the honest answer,
    // not a fabricated merge algorithm.
    const conflictStrategy = ConflictStrategy.none;

    final offlineFeature = featureGraph?.nodeById('feature:offline');
    final rationale = offlineFeature != null
        ? '${candidate.offline.decision.rationale} Confirmed by Feature '
              'Discovery\'s Offline Strategy feature (priority: '
              '${offlineFeature.priority.name}).'
        : candidate.offline.decision.rationale;

    return OfflineEngineeringResult(
      strategy: strategy,
      conflictStrategy: conflictStrategy,
      decision: EngineeringDecision(
        id: 'offline:strategy',
        category: EngineeringDecisionCategory.offline,
        subjectId: 'offline',
        decision: 'Offline strategy: ${strategy.name}',
        rationale: rationale,
        confidence: candidate.offline.decision.confidence,
      ),
    );
  }
}

class SynchronizationEngineeringResult {
  final SyncStrategy strategy;
  final EngineeringDecision decision;

  const SynchronizationEngineeringResult({
    required this.strategy,
    required this.decision,
  });
}

class SynchronizationEngineering {
  const SynchronizationEngineering();

  SynchronizationEngineeringResult plan(ArchitectureCandidate candidate) {
    return SynchronizationEngineeringResult(
      strategy: candidate.synchronization.strategy,
      decision: EngineeringDecision(
        id: 'synchronization:plan',
        category: EngineeringDecisionCategory.synchronization,
        subjectId: 'synchronization',
        decision:
            'Synchronization strategy: ${candidate.synchronization.strategy.name} '
            '(architecture-only — no server/cloud sync implementation exists or is planned here)',
        rationale:
            'Anything has no server component today. This decision records '
            'the *intended* client-side strategy (cache-first vs. none) for '
            'a future cloud-sync milestone; no network client code is '
            'generated by this decision, matching the "nothing implemented '
            'with servers, only architecture" instruction.',
        confidence: Confidence.full,
      ),
    );
  }
}
