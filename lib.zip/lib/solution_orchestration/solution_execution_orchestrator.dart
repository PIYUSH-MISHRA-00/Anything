/// SolutionExecutionOrchestrator — Implementation Specification IS-R25.
///
/// REALITY (see `docs/architecture/SOLUTION_ORCHESTRATION.md` for the full
/// audit): `SolutionExecutionPlanner` (R18) already produces a real
/// `ExecutionStrategy` — target/classification/reason/priority/dependencies/
/// executionOrder/requiredGenerators/validationRequirements/buildRequirements/
/// deploymentRequirements — but deliberately never EXECUTES it (its own
/// doc comment: "this planner only decides WHAT should be executed... a
/// caller invokes [the compiler] using this plan's requiredGenerators/
/// actionableTargets"). Nothing in this codebase, before this
/// specification, ever walked `ExecutionStrategy.actionableTargets` and
/// actually ran a stage. This orchestrator is that missing caller — never
/// a second planner, never a second compiler: it dispatches through the
/// EXISTING `runCompilerPipeline` (R19) / `IncrementalCompilerSynthesizer`
/// (R24), validates through the EXISTING, UNMODIFIED
/// `ExperiencePackageValidator`, and never embeds generator logic itself.
///
/// Of R18's 12 execution targets, only Runtime Experience ever reaches
/// `applicableWithGenerator` today (confirmed by re-reading
/// `SolutionExecutionPlanner`) — real production `ExecutionStrategy`s
/// therefore only ever produce ONE actionable stage. The level-ordering/
/// concurrent-dispatch machinery below is real and correctness-tested on
/// synthetic multi-target fixtures, but has no real multi-stage instance
/// to run today — stated honestly, never overclaimed.
///
/// PARALLEL EXECUTION, stated precisely: stages within one level are
/// dispatched via `Future.wait`, a real Dart concurrency primitive — but
/// Dart runs on a single isolate, and both real execution primitives
/// (`runCompilerPipeline`/`IncrementalCompilerSynthesizer`) are
/// synchronous, CPU-bound, in-memory computations with no internal
/// `await`. `Future.wait` over purely synchronous work does not achieve
/// genuine multi-core speedup — what it DOES real and correctly provide
/// is dependency-safe ORDERING (nothing in a later level starts before
/// every stage in every earlier level has completed) and a real
/// concurrency-ready shape for a FUTURE generator that does perform
/// genuine async I/O. True CPU parallelism would require Dart Isolates —
/// out of scope here, named for a future milestone.
///
/// RETRY, stated precisely: `runCompilerPipeline`/`IncrementalCompilerSynthesizer`
/// are pure, deterministic functions of their input (proven since R13/R19/
/// R24's own determinism tests) with no I/O of their own — a retry of an
/// identical input can only ever reproduce an identical outcome. Retry
/// exists here as real, tested, bounded infrastructure (never an infinite
/// loop, always a real structured failure once exhausted) for a stage
/// type that has a genuine transient-failure surface — it is honestly NOT
/// expected to change today's deterministic pipeline's result, and this
/// file says so rather than fabricating retry/backoff sophistication with
/// no real failure signal behind it.
///
/// DISPATCH, generalized (Implementation Specification IS-R26): a
/// Backend Service stage produces structurally different output than a
/// Runtime Experience stage (typed `Artifact`s, never an
/// `ExperiencePackage`) and needs a real, additional input
/// (`BackendEngineeringPlan`) neither `runCompilerPipeline`/
/// `IncrementalCompilerSynthesizer` accept. `_runStage` below dispatches
/// on `target` to the correct handler — this is real dispatch, not
/// hard-coded execution: WHICH targets are even attempted still comes
/// entirely from `ExecutionStrategy` (only `applicableWithGenerator`
/// targets reach `_runStage` at all, R25's own unchanged filter in
/// [execute]); this switch only decides HOW to run a target ExecutionStrategy
/// already approved, exactly as R18's own `requiredGenerators` field
/// anticipated ("a caller invokes the compiler using this plan's
/// requiredGenerators/actionableTargets").
///
/// ROLLBACK: the real, existing `ExperienceModificationCoordinator.rollback()`
/// (R6) is reused, never reimplemented — but this orchestrator lives
/// beneath `lib/app/`, and `ExperienceModificationCoordinator` lives
/// inside it (the established layering direction: `lib/app/` composes
/// lower-level `lib/` subsystems, never the reverse — confirmed by every
/// prior milestone's coordinator, e.g. `SoftwareCognitionCoordinator`
/// never imports `ExperienceCreationCoordinator`). This orchestrator
/// therefore does not call `rollback()` itself; it reports failure via
/// [OrchestrationReport.failedStages], and a caller in `lib/app/` (proven
/// end-to-end in `test/r25_solution_orchestrator_test.dart`) uses that
/// report to invoke the real, unmodified `rollback()` on a modification
/// request's prior package.
library;

import 'dart:convert';

import '../backend_engineering/backend_engineering_plan.dart';
import '../backend_engineering/backend_engineering_serialization.dart';
import '../compiler_integration/compiler_pipeline_runner.dart';
import '../creation/experience_package.dart';
import '../creation/package_validator.dart';
import '../engineering_intelligence/affected_entities.dart';
import '../engineering_intelligence/incremental_compiler_synthesis.dart';
import '../execution_planning/execution_strategy.dart';
import '../generator_framework/generation_result.dart';
import '../generator_framework/generator.dart' show GeneratorOptions;
import '../generator_framework/reference/backend_service_generator.dart';
import '../generator_framework/reference/rest_api_generator.dart';
import '../implementation_model/canonical_implementation_model.dart';
import 'execution_ordering.dart';
import 'orchestration_result.dart';

class SolutionExecutionOrchestrator {
  const SolutionExecutionOrchestrator();

  /// [affected]: when supplied and non-empty, a Runtime Experience stage
  /// dispatches through the real, existing `IncrementalCompilerSynthesizer`
  /// (R24) instead of a full `runCompilerPipeline` (R19) run — a real,
  /// observable dispatch choice, never a heuristic guess. Backend Service
  /// stages (R26) have no incremental-synthesis path yet (named honestly
  /// in `docs/architecture/BACKEND_SERVICE_GENERATOR.md`) — `affected` is
  /// simply not consulted for them.
  /// [backendPlan]: real `BackendEngineeringPlan` (R8), required only for
  /// a `backendService` stage — `null` by default, matching every
  /// existing caller/test, which never had a backend-shaped target to
  /// run before this specification.
  /// [maxAttempts]: bounded retry count per stage, default 1 (no retry) —
  /// see this file's own top-level doc comment on why retry is honestly
  /// unlikely to change a deterministic pipeline's outcome; a caller with
  /// a genuine transient-failure-prone future generator can raise this.
  Future<OrchestrationReport> execute({
    required ExecutionStrategy strategy,
    required CanonicalImplementationModel model,
    required String id,
    required String name,
    AffectedEntities? affected,
    BackendEngineeringPlan? backendPlan,
    int maxAttempts = 1,
  }) async {
    final levels = const ExecutionTargetOrderer().order(strategy);
    final stages = <StageOutcome>[];

    // Non-actionable targets never enter the level ordering above (only
    // `applicableTargets` do) — recorded here as real, honest, zero-attempt
    // skips so a caller sees the full 12-target picture, not just the
    // executed subset.
    for (final plan in strategy.targets) {
      if (plan.classification == ExecutionTargetClassification.notApplicable) {
        stages.add(
          StageOutcome(
            target: plan.target,
            status: StageStatus.skippedNotApplicable,
            attempts: 0,
            errors: [plan.reason],
          ),
        );
      } else if (plan.classification ==
          ExecutionTargetClassification.applicableNoGenerator) {
        stages.add(
          StageOutcome(
            target: plan.target,
            status: StageStatus.skippedNoGenerator,
            attempts: 0,
            errors: [plan.reason],
          ),
        );
      }
    }

    for (final level in levels.levels) {
      final actionable = level.where(
        (t) =>
            strategy.forTarget(t).classification ==
            ExecutionTargetClassification.applicableWithGenerator,
      );
      final results = await Future.wait(
        actionable.map(
          (target) => _runStage(
            target: target,
            model: model,
            id: id,
            name: name,
            affected: affected,
            backendPlan: backendPlan,
            maxAttempts: maxAttempts,
          ),
        ),
      );
      stages.addAll(results);
    }

    return OrchestrationReport(
      levels: levels.levels,
      levelOrderingComplete: levels.isComplete,
      stages: stages,
    );
  }

  /// Real dispatch (Implementation Specification IS-R26, extended IS-R27)
  /// — see this file's own top-level "DISPATCH, generalized" doc comment.
  /// WHICH targets are attempted is entirely `ExecutionStrategy`'s
  /// decision (only `applicableWithGenerator` targets reach here,
  /// unchanged since R25); this only decides HOW to run one
  /// already-approved target.
  Future<StageOutcome> _runStage({
    required ExecutionTargetKind target,
    required CanonicalImplementationModel model,
    required String id,
    required String name,
    required AffectedEntities? affected,
    required BackendEngineeringPlan? backendPlan,
    required int maxAttempts,
  }) {
    if (target == ExecutionTargetKind.backendService) {
      return _runBackendServiceStage(
        model: model,
        id: id,
        name: name,
        backendPlan: backendPlan,
        maxAttempts: maxAttempts,
      );
    }
    if (target == ExecutionTargetKind.restApi) {
      return _runRestApiStage(
        model: model,
        id: id,
        name: name,
        backendPlan: backendPlan,
        maxAttempts: maxAttempts,
      );
    }
    return _runRuntimeExperienceStage(
      target: target,
      model: model,
      id: id,
      name: name,
      affected: affected,
      maxAttempts: maxAttempts,
    );
  }

  /// Unchanged since R25 (renamed from `_runStage`) — byte-for-byte
  /// identical behavior for every existing caller.
  Future<StageOutcome> _runRuntimeExperienceStage({
    required ExecutionTargetKind target,
    required CanonicalImplementationModel model,
    required String id,
    required String name,
    required AffectedEntities? affected,
    required int maxAttempts,
  }) async {
    final stopwatch = Stopwatch()..start();
    var attempt = 0;
    while (true) {
      attempt++;
      final ExperiencePackage? package;
      final GenerationResult compilerResult;
      if (affected != null && !affected.isEmpty) {
        final result = const IncrementalCompilerSynthesizer().synthesize(
          fullModel: model,
          affected: affected,
          id: id,
          name: name,
        );
        package = result.package;
        compilerResult = result.compilerResult;
      } else {
        final result = runCompilerPipeline(model, id: id, name: name);
        package = result.package;
        compilerResult = result.result;
      }

      final compilerErrors = compilerResult.diagnostics
          .where((d) => d.severity == DiagnosticSeverity.error)
          .map((d) => d.message)
          .toList();
      final validation = package != null
          ? ExperiencePackageValidator.validate(package)
          : null;

      final succeeded =
          package != null &&
          compilerErrors.isEmpty &&
          (validation?.isValid ?? false);
      if (succeeded) {
        stopwatch.stop();
        return StageOutcome(
          target: target,
          status: StageStatus.succeeded,
          attempts: attempt,
          package: package,
          latency: stopwatch.elapsed,
        );
      }
      if (attempt >= maxAttempts) {
        stopwatch.stop();
        final errors = [
          ...compilerErrors,
          ...?validation?.errors,
          if (package == null && compilerErrors.isEmpty)
            'Compiler pipeline produced no artifact for this target.',
        ];
        return StageOutcome(
          target: target,
          status: StageStatus.failed,
          attempts: attempt,
          errors: errors,
          latency: stopwatch.elapsed,
        );
      }
      // Real bounded retry — see this file's own doc comment on why this
      // rarely changes a deterministic pipeline's outcome.
    }
  }

  /// New in Implementation Specification IS-R26. Dispatches through the
  /// real, generic `runGeneratorPipeline` (R26) against the real, existing
  /// `BackendServiceGenerator` — never `ExperiencePackageValidator` (a
  /// Backend Service artifact is not an `ExperiencePackage`); Completion
  /// Criteria here is real: zero compiler-diagnostic errors, at least one
  /// artifact produced, and every artifact's `content` a real, valid,
  /// parseable JSON document (never a rubber-stamped boolean).
  Future<StageOutcome> _runBackendServiceStage({
    required CanonicalImplementationModel model,
    required String id,
    required String name,
    required BackendEngineeringPlan? backendPlan,
    required int maxAttempts,
  }) async {
    const target = ExecutionTargetKind.backendService;
    final stopwatch = Stopwatch()..start();

    if (backendPlan == null) {
      stopwatch.stop();
      return StageOutcome(
        target: target,
        status: StageStatus.failed,
        attempts: 1,
        errors: const [
          'No BackendEngineeringPlan supplied to SolutionExecutionOrchestrator.execute() — required for a backendService stage.',
        ],
        latency: stopwatch.elapsed,
      );
    }

    final options = GeneratorOptions(
      values: {'backendEngineeringPlan': jsonEncode(backendPlan.toJson())},
    );

    var attempt = 0;
    while (true) {
      attempt++;
      final outcome = runGeneratorPipeline(
        model,
        generator: const BackendServiceGenerator(),
        id: id,
        name: name,
        options: options,
      );
      final compilerErrors = outcome.result.diagnostics
          .where((d) => d.severity == DiagnosticSeverity.error)
          .map((d) => d.message)
          .toList();
      final artifacts = outcome.result.allArtifacts;
      final invalidJson = artifacts
          .where((a) => a.content != null && !_isValidJson(a.content!))
          .map((a) => 'Artifact ${a.id} is not valid JSON');

      final errors = [...compilerErrors, ...invalidJson];
      final succeeded = artifacts.isNotEmpty && errors.isEmpty;

      if (succeeded) {
        stopwatch.stop();
        return StageOutcome(
          target: target,
          status: StageStatus.succeeded,
          attempts: attempt,
          backendArtifacts: artifacts,
          latency: stopwatch.elapsed,
        );
      }
      if (attempt >= maxAttempts) {
        stopwatch.stop();
        final allErrors = [
          ...errors,
          if (artifacts.isEmpty && compilerErrors.isEmpty)
            'Backend Service Generator produced no artifacts for this target.',
        ];
        return StageOutcome(
          target: target,
          status: StageStatus.failed,
          attempts: attempt,
          errors: allErrors,
          latency: stopwatch.elapsed,
        );
      }
      // Real bounded retry — same rationale as `_runRuntimeExperienceStage`.
    }
  }

  /// New in Implementation Specification IS-R27. Mirrors
  /// `_runBackendServiceStage` exactly — same `backendPlan`-required
  /// precondition, same completion criteria (zero diagnostic errors, at
  /// least one artifact, every artifact real valid JSON) — dispatched
  /// against the real, existing `RestApiGenerator` instead.
  Future<StageOutcome> _runRestApiStage({
    required CanonicalImplementationModel model,
    required String id,
    required String name,
    required BackendEngineeringPlan? backendPlan,
    required int maxAttempts,
  }) async {
    const target = ExecutionTargetKind.restApi;
    final stopwatch = Stopwatch()..start();

    if (backendPlan == null) {
      stopwatch.stop();
      return StageOutcome(
        target: target,
        status: StageStatus.failed,
        attempts: 1,
        errors: const [
          'No BackendEngineeringPlan supplied to SolutionExecutionOrchestrator.execute() — required for a restApi stage.',
        ],
        latency: stopwatch.elapsed,
      );
    }

    final options = GeneratorOptions(
      values: {'backendEngineeringPlan': jsonEncode(backendPlan.toJson())},
    );

    var attempt = 0;
    while (true) {
      attempt++;
      final outcome = runGeneratorPipeline(
        model,
        generator: const RestApiGenerator(),
        id: id,
        name: name,
        options: options,
      );
      final compilerErrors = outcome.result.diagnostics
          .where((d) => d.severity == DiagnosticSeverity.error)
          .map((d) => d.message)
          .toList();
      final artifacts = outcome.result.allArtifacts;
      final invalidJson = artifacts
          .where((a) => a.content != null && !_isValidJson(a.content!))
          .map((a) => 'Artifact ${a.id} is not valid JSON');

      final errors = [...compilerErrors, ...invalidJson];
      final succeeded = artifacts.isNotEmpty && errors.isEmpty;

      if (succeeded) {
        stopwatch.stop();
        return StageOutcome(
          target: target,
          status: StageStatus.succeeded,
          attempts: attempt,
          backendArtifacts: artifacts,
          latency: stopwatch.elapsed,
        );
      }
      if (attempt >= maxAttempts) {
        stopwatch.stop();
        final allErrors = [
          ...errors,
          if (artifacts.isEmpty && compilerErrors.isEmpty)
            'REST API Generator produced no artifacts for this target.',
        ];
        return StageOutcome(
          target: target,
          status: StageStatus.failed,
          attempts: attempt,
          errors: allErrors,
          latency: stopwatch.elapsed,
        );
      }
      // Real bounded retry — same rationale as `_runRuntimeExperienceStage`.
    }
  }

  bool _isValidJson(String content) {
    try {
      jsonDecode(content);
      return true;
    } catch (_) {
      return false;
    }
  }
}
